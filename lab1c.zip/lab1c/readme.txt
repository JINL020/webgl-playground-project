Claim: 
	FOUNDATIONS - My labyrinth is build using cubes as building blocks which are read in with the objLoader
    and then translated to the desired position. The pattern can be set in Maze class this.map.
    The plane is also read in with the objLoader.
    I have 4 differnt Pacman .obj files that get drawn in a sequence so the my pacman looks animated. The chewingTimer determines when the animation sequence
    get udpated. Pacman turns continuously into and face in the direction of the movement.

	GRAPHICAL ASPECTS - tried to do a shear-view.

	GAMING ASPECTS - not implemented

	AVDVANCED GAMING ASPECTS - not implemented 

Tested environment:
	I used python -m http.server to locally host my project.
	OS: Windows
	Browser: chrome Version 95.0.4638.69

Additional and general remarks: